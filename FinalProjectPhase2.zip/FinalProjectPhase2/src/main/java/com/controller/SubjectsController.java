package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Student;
import com.bean.Subjects;
import com.service.StudentService;
import com.service.SubjectsService;

/**
 * Servlet implementation class ClassesController
 */
public class SubjectsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubjectsController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		SubjectsService sbs = new SubjectsService();
		List<Subjects> listOfSubjects=sbs.findAllSubject();
		HttpSession hs = request.getSession();
		hs.setAttribute("listOfSubjects", listOfSubjects);
		response.setContentType("text/html");
		response.sendRedirect("viewSubjects.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		int sbid = Integer.parseInt(request.getParameter("sbid"));
		String sbname = request.getParameter("sbname");
	
		Subjects sb = new Subjects();
		sb.setSbid(sbid);
		sb.setSbname(sbname);
		SubjectsService sbs = new SubjectsService();
		String result = sbs.storeSubjects(sb);
		pw.print(result);
		RequestDispatcher rd = request.getRequestDispatcher("storeSubjects.jsp");
		rd.include(request, response);
	}

}

