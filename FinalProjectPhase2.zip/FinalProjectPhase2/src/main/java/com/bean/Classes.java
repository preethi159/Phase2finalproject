package com.bean;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class Classes {
	@Id
	private int cid;
	private String csec;
     @OneToMany
     @JoinColumn(name="csid")
	List<Student> listOfStud;
     @OneToMany
 	@JoinColumn(name="ctid")
 	private List<Trainer> lisOfTrainer;
     @OneToMany
 	@JoinColumn(name="csbid")
 	private List<Subjects> lisOfSub;
     private Integer sbcid;
     private Integer tcid;
     private Integer scid;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCsec() {
		return csec;
	}
	public void setCsec(String csec) {
		this.csec = csec;
	}
	public List<Student> getListOfStud() {
		return listOfStud;
	}
	public void setListOfStud(List<Student> listOfStud) {
		this.listOfStud = listOfStud;
	}
	public List<Trainer> getLisOfTrainer() {
		return lisOfTrainer;
	}
	public void setLisOfTrainer(List<Trainer> lisOfTrainer) {
		this.lisOfTrainer = lisOfTrainer;
	}
	public List<Subjects> getLisOfSub() {
		return lisOfSub;
	}
	public void setLisOfSub(List<Subjects> lisOfSub) {
		this.lisOfSub = lisOfSub;
	}
	public Integer getSbcid() {
		return sbcid;
	}
	public void setSbcid(Integer sbcid) {
		this.sbcid = sbcid;
	}
	public Integer getTcid() {
		return tcid;
	}
	public void setTcid(Integer tcid) {
		this.tcid = tcid;
	}
	public Integer getScid() {
		return scid;
	}
	public void setScid(Integer scid) {
		this.scid = scid;
	}
	@Override
	public String toString() {
		return "Classes [cid=" + cid + ", csec=" + csec + ", listOfStud=" + listOfStud + ", lisOfTrainer="
				+ lisOfTrainer + ", lisOfSub=" + lisOfSub + ", sbcid=" + sbcid + ", tcid=" + tcid + ", scid=" + scid
				+ "]";
	}
}
	