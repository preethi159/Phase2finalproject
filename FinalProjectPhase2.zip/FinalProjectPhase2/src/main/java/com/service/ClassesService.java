package com.service;

import java.util.List;

import com.dao.ClassesDao;
import com.bean.Classes;

public class ClassesService {
ClassesDao cd = new ClassesDao();
    
    public String storeClasses(Classes classs) {
        if(cd.storeClasses(classs)>0) {
            return "class details stored successfully";
        }else {
            return "class details didn't store";
        }
    }
    
    public List<Classes> findAllClasses() {
        return cd.findAllClasses();
    }

}



